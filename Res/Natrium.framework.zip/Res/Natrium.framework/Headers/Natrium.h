//
//  Natrium.h
//  Natrium
//
//  Created by Bas van Kuijck on 19/12/2017.
//  Copyright © 2017 E-sites. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Natrium.
FOUNDATION_EXPORT double NatriumVersionNumber;

//! Project version string for Natrium.
FOUNDATION_EXPORT const unsigned char NatriumVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Natrium/PublicHeader.h>


